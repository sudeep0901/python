#two.py
import Demo_run_directly

print("top-level in two.py")
Demo_run_directly.func()

if __name__ == "__main__":
    print("two.py is being run directly")
else:
    print("two.py is being imported into another module")
