fo = open("C:\D_Drive\Training\Python\Demo\email.txt", "r")
fb = open("C:\D_Drive\Training\Python\Demo\email_new.txt", "w")
count = 0
for line in fo:
	if line.strip().endswith('capgemini.com'):
		fb.write( line)
		count +=1;
print ("Total Count:", count)
fo.close()
fb.close()    
